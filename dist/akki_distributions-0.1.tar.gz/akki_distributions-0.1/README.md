Creating a PyPI package

Table of Contents

Project Motivation
Installation
Acknowledgements
Project Motivation

This project was created as part of Udacity's Data Scientist for Enterprise nanodegree. This is just a sample project which calculates Gaussian and Binomial distributions.

Installation

The code should run using any Python versions 3.*

Libraries Used : matplotlib

If you don't have python already installed, I would suggest you to install the Anaconda distribution of Python, as you will get all the necessary libraries together.

Acknowledgements

Thanks to Udacity.