from setuptools import setup

setup(name='akki_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['akki_distributions'],
      author = 'Akshay Jaitly',
      zip_safe=False)